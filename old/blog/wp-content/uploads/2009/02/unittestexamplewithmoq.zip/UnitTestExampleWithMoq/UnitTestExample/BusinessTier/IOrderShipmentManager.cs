﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnitTestExample.DataObjects;

namespace UnitTestExample.BusinessTier
{
    public interface IOrderShipmentManager
    {
        Shipment ShipOrder(int orderId);
    }
}
