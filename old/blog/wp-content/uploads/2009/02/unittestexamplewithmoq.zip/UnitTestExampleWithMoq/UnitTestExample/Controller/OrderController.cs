﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnitTestExample.DataObjects;
using UnitTestExample.BusinessTier;

namespace UnitTestExample
{
    public class ShipmentTrackerController
    {
        public void ShipProduct(int orderId)
        {
            IOrderShipmentManager opm = new OrderShipmentManager(new DataTier.OrderStorage(), new DataTier.ShipmentService());
            Shipment shipment = null;

            try
            {
                shipment = opm.ShipOrder(orderId);
            }
            catch (OrderShipmentException ope)
            {
                System.Diagnostics.Debug.Write("Whoops: {0}", ope.Message);
            }

            View(shipment);
        }

        public void View(object data)
        {
        }
    }
}
