﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnitTestExample.DataObjects;

namespace UnitTestExample.DataTier
{
    public interface IShipmentService
    {
        Shipment CreateShipment(int customerId);
        void CalculateShipment(Shipment shipment);
        bool Ship(Shipment shipment);
        
    }
}
