﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using UnitTestExample.BusinessTier;
using UnitTestExample.DataTier;
using UnitTestExample.DataObjects;
using Moq;


namespace Tests.UnitTestExample
{
    
    
    /// <summary>
    ///This is a test class for OrderShipmentManagerTest and is intended
    ///to contain all OrderShipmentManagerTest Unit Tests
    ///</summary>
    [TestClass()]
    public class OrderShipmentManagerTest
    {

        private Order createOrder(int id)
        {
            var order = new Order() { OrderId = id, Customer = new Customer() { CustomerId = 1 }, OrderItems = new List<OrderItem>() };
            order.OrderItems.Add(new OrderItem() { Price = 10.00, Product = new Product() { ProductId = 1, ProductName = "Test" } });
            return order;
        }

        private Shipment createShipment(int id)
        {
            var currentShipment = new Shipment();
            currentShipment.CustomerId = id;
            return currentShipment;
        }
        /// <summary>
        ///A test for ShipOrder
        ///</summary>
        [TestMethod()]
        public void OrderShipmentManager_ShipOrder_Returns_New_Shipment_With_Shipment_Items()
        {
            var mockOrderStorage = new Mock<IOrderStorage>();
            var mockShipmentService = new Mock<IShipmentService>();

            mockOrderStorage.Setup(os => os.GetOrder(It.IsAny<int>())).Returns((int id) => {
               return createOrder(id);
            });

            mockShipmentService.Setup(ss => ss.CreateShipment(It.IsAny<int>())).Returns((int id) =>
            {
                return createShipment(id);
            });
            var osm = new OrderShipmentManager(mockOrderStorage.Object, mockShipmentService.Object);

            var shipment = osm.ShipOrder(5);

            Assert.IsNotNull(shipment, "Returned Shipment was not null");
            Assert.IsInstanceOfType(shipment, typeof(Shipment), "Returned object was not of type shipment.");
            Assert.IsNotNull(shipment.ShipmentProducts, "ShipmentProducts were null");
            Assert.IsTrue(shipment.ShipmentProducts.Count > 0, "ShipmentProducts were empty");


        }
        [TestMethod()]
        public void OrderShipmentManager_ShipOrder_Throws_OrderShipmentException_When_OrderId_Is_Less_Than_Zero()
        {
        }

        [TestMethod()]
        public void OrderShipmentManager_ShipOrder_Throws_OrderShipmentException_When_Order_Status_Is_Shipped()
        {
           
        }
        [TestMethod()]
        public void OrderShipmentManager_ShipOrder_Returns_Null_When_No_Shipment()
        {
        }
        [TestMethod()]
        public void OrderShipmentManager_ShipOrder_Gets_Order_From_Storage()
        {

        }
        [TestMethod()]
        public void OrderShipmentManager_ShipOrder_Saves_Order_With_ShipmentId_And_Status()
        {
        }
        [TestMethod()]
        public void OrderShipmentManager_ShipOrder_Creates_Shipment_For_Customer()
        {
        }
        [TestMethod()]
        public void OrderShipmentManager_ShipOrder_Copies_OrderItems_To_Shipment()
        {
        }
        [TestMethod()]
        public void OrderShipmentManager_ShipOrder_Calculates_Shipment()
        {
        }
        [TestMethod()]
        public void OrderShipmentManager_ShipOrder_Ships_Product()
        {
            var mockOrderStorage = new Mock<IOrderStorage>();
            var mockShipmentService = new Mock<IShipmentService>();

            mockOrderStorage.Setup(os => os.GetOrder(It.IsAny<int>())).Returns((int id) =>
            {
                return createOrder(id);
            });

            mockShipmentService.Setup(ss => ss.CreateShipment(It.IsAny<int>())).Returns((int id) =>
            {
                return createShipment(id);
            });

            var osm = new OrderShipmentManager(mockOrderStorage.Object, mockShipmentService.Object);

            var shipment = osm.ShipOrder(1);

            try
            {
                mockShipmentService.Verify(svc => svc.Ship(shipment));
            }
            catch (Exception ex)
            {
                Assert.Fail("Moq.Verify on Ship(shipment) failed with {0}", ex.Message);
            }
        }
    }
}
