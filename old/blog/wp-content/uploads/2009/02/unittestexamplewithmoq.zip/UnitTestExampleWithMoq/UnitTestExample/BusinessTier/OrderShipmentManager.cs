﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnitTestExample.DataTier;
using UnitTestExample.DataObjects;

namespace UnitTestExample.BusinessTier
{
    public class OrderShipmentManager : IOrderShipmentManager
    {
        private IOrderStorage _orderStorage;
        private IShipmentService _shipmentService;

        public OrderShipmentManager(IOrderStorage orderStorage, IShipmentService shipmentService)
        {
            _orderStorage = orderStorage;
            _shipmentService = shipmentService;
        }

        public Shipment ShipOrder(int orderId)
        {
            Order order;
            Shipment shipment;

            if (orderId < 0)
                throw new OrderShipmentException("OrderId cannot be less than zero");

           order = _orderStorage.GetOrder(orderId);
         
            if (order == null)
                return null;

            if (order.ShipmentStatus == ShipmentStatus.Shipped)
            {
                throw new OrderShipmentException("Can't ship an order that's shipped!");
            }

            shipment = _shipmentService.CreateShipment(order.Customer.CustomerId);
        
            shipment.ShipmentProducts = new List<Product>();
            order.OrderItems.ForEach(oi => shipment.ShipmentProducts.Add(oi.Product));

            _shipmentService.CalculateShipment(shipment);
            _shipmentService.Ship(shipment);
          

            order.ShipmentStatus = ShipmentStatus.Shipped;
            order.ShipmentId = shipment.ShipmentId;

            _orderStorage.SaveOrder(order);

            return shipment;
        }
    }
}
