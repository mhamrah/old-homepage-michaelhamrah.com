﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UnitTestExample.DataObjects
{
    public class Order
    {
        public int OrderId { get; set; }
        public Customer Customer { get; set; }
        public List<OrderItem> OrderItems { get; set; }
        public ShipmentStatus ShipmentStatus { get; set; }
        public int ShipmentId { get; set; }
    }
    public enum ShipmentStatus
    {
        NotShipped = 1,
        Shipped = 2
    }
   
}
