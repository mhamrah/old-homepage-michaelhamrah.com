﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UnitTestExample.DataObjects
{
    public class OrderItem
    {
        public Product Product { get; set; }
        public double Price { get; set; }
    }
}
