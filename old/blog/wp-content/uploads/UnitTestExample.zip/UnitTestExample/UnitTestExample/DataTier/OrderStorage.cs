﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnitTestExample.DataObjects;

namespace UnitTestExample.DataTier
{
    public class OrderStorage : IOrderStorage
    {

        public Order GetOrder(int orderId)
        {
            Console.WriteLine("Getting order {0}...", orderId.ToString());

            return new Order() {
                OrderId = orderId,
                Customer = new Customer()
                {
                    CustomerId = new Random().Next(),
                    CustomerName = "Joe the Programmer."
                },
                OrderItems = new List<OrderItem>() {
                    new OrderItem()
                    {
                        Price = 10.00,
                        Product = new Product() { ProductId = new Random().Next(), ProductName="Keyboard"}
                    },
                    new OrderItem()
                    {
                        Price = 25.00,
                        Product = new Product() { ProductId = new Random().Next(), ProductName="Monitor"}
                    }

                }
            };


        }

        public bool SaveOrder(Order order)
        {
            return true;
        }

       
    }
}
