﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnitTestExample.DataObjects;

namespace UnitTestExample.DataTier
{
    public interface IOrderStorage
    {
         Order GetOrder(int orderId);
         bool SaveOrder(Order order);
    }
}
