﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnitTestExample.DataObjects;

namespace UnitTestExample.DataTier
{
    public class ShipmentService : IShipmentService
    {
      
        public Shipment CreateShipment(int customerId)
        {
            return new Shipment()
            {
                ShipmentId = new Random().Next(),
                CustomerId = customerId
            };
        }

        public void CalculateShipment(Shipment shipment)
        {
            shipment.ShippingCost = Convert.ToDouble(new Random(1).Next(100));
        }
        public bool Ship(Shipment shipment)
        {
            return true;
        }

    }
}
