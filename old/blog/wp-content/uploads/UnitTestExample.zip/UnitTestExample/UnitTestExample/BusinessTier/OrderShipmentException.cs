﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UnitTestExample.BusinessTier
{
    public class OrderShipmentException : Exception
    {
        public OrderShipmentException()
            : base()
        {
        }
        public OrderShipmentException(string message)
            : base(message)
        {
        }
        public OrderShipmentException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
}
