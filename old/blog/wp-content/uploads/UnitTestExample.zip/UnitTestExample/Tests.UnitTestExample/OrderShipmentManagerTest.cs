﻿using UnitTestExample.BusinessTier;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using UnitTestExample.DataTier;
using UnitTestExample.DataObjects;

namespace Tests.UnitTestExample
{
    
    
    /// <summary>
    ///This is a test class for OrderShipmentManagerTest and is intended
    ///to contain all OrderShipmentManagerTest Unit Tests
    ///</summary>
    [TestClass()]
    public class OrderShipmentManagerTest
    {
        /// <summary>
        ///A test for ShipOrder
        ///</summary>
        [TestMethod()]
        public void OrderShipmentManager_ShipOrder_Returns_New_Shipment_With_Order_Items()
        {
        }
        [TestMethod()]
        public void OrderShipmentManager_ShipOrder_Throws_OrderShipmentException_When_OrderId_Is_Less_Than_Zero()
        {
        }

        [TestMethod()]
        public void OrderShipmentManager_ShipOrder_Throws_OrderShipmentException_When_Order_Status_Is_Shipped()
        {
        }
        [TestMethod()]
        public void OrderShipmentManager_ShipOrder_Returns_Null_When_No_Shipment()
        {
        }
        [TestMethod()]
        public void OrderShipmentManager_ShipOrder_Gets_Order_From_Storage()
        {
        }
        [TestMethod()]
        public void OrderShipmentManager_ShipOrder_Saves_Order_With_ShipmentId_And_Status()
        {
        }
        [TestMethod()]
        public void OrderShipmentManager_ShipOrder_Creates_Shipment_For_Customer()
        {
        }
        [TestMethod()]
        public void OrderShipmentManager_ShipOrder_Copies_OrderItems_To_Shipment()
        {
        }
        [TestMethod()]
        public void OrderShipmentManager_ShipOrder_Calculates_Shipment()
        {
        }
        [TestMethod()]
        public void OrderShipmentManager_ShipOrder_Ships_Product()
        {
        }
    }
}
