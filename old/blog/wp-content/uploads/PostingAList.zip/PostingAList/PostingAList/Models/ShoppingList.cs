﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PostingAList.Models
{
    public class ShoppingList
    {
        public string ListName { get; set; }
        public IList<ShoppingItem> Items { get; set; }
    }
}
