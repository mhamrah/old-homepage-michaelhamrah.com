﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;
using PostingAList.Models;

namespace PostingAList.Controllers
{
    public class ShoppingController : Controller
    {
        public ActionResult Index()
        {
            ViewData["Title"] = "Saving a list of items";

            return View();
        }

        public ActionResult Save(ShoppingList myList)
        {
          


            return View(myList);
        }
        
        public ActionResult ShoppingItemFormContent(string prefix)
        {
            ViewData["GUID"] = Guid.NewGuid().ToString();
            ViewData["Prefix"] = prefix;

            return View("ShoppingItemFormContent");
        }
    }
}
