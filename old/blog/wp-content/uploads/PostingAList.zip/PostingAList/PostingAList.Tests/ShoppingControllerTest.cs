﻿using PostingAList.Controllers;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.VisualStudio.TestTools.UnitTesting.Web;
using System.Collections.Generic;
using PostingAList.Models;
using System.Web.Mvc;
using Commerce.Tests;

namespace PostingAList.Tests
{
    
    
    /// <summary>
    ///This is a test class for ShoppingControllerTest and is intended
    ///to contain all ShoppingControllerTest Unit Tests
    ///</summary>
    [TestClass()]
    public class ShoppingControllerTest
    {
        [TestMethod()]
        public void SaveTest()
        {
            var shoppingController = new ShoppingController();
          
            shoppingController.SetFakeControllerContext();

            shoppingController.Request.Form.Add("myList.ListName", "My Shopping List");
            shoppingController.Request.Form.Add("myList.Items.Index", "1");
            shoppingController.Request.Form.Add("myList.Items[1].Name", "Chocolate");
            shoppingController.Request.Form.Add("myList.Items[1].Quantity", "5");
            shoppingController.Request.Form.Add("myList.Items.Index", "Alpha");
            shoppingController.Request.Form.Add("myList.Items[Alpha].Name", "Graham Crackers");
            shoppingController.Request.Form.Add("myList.Items[Alpha].Quantity", "10");
  
            shoppingController.HttpContext.Request.SetHttpMethodResult("POST");

            var defaultBinding = ModelBinders.GetBinder(typeof(ShoppingList));
            var bindingContext = new ModelBindingContext(shoppingController.ControllerContext, 
                shoppingController.ValueProvider, 
                typeof(ShoppingList), 
                "myList", null, shoppingController.ModelState, null);
            var binderResult = defaultBinding.BindModel(bindingContext);

            Assert.IsNotNull(binderResult);
            Assert.IsNotNull(binderResult.Value);
            Assert.IsInstanceOfType(binderResult.Value, typeof(ShoppingList));

            var myList = binderResult.Value as ShoppingList;

            Assert.IsTrue(myList.ListName == "My Shopping List");
            Assert.IsTrue(myList.Items.Count > 0);
            Assert.IsTrue(myList.Items[0].Name == "Chocolate");
            Assert.IsTrue(myList.Items[0].Quantity == 5);

            Assert.IsTrue(myList.Items[1].Name == "Graham Crackers");
            Assert.IsTrue(myList.Items[1].Quantity == 10);

            var controllerResult = shoppingController.Save(myList);

            Assert.IsNotNull(controllerResult);
            Assert.IsInstanceOfType(controllerResult, typeof(ViewResult));



        }
    }
}
