# WordPress MySQL database backup
#
# Generated: Friday 13. March 2009 11:34 EDT
# Hostname: 192.168.1.6
# Database: `hamrahwp`
# --------------------------------------------------------
